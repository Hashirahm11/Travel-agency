import React from 'react';
import { Link } from 'react-router-dom';
import { MapPin, Mail, Phone, Clock, ShieldCheck, Compass, ExternalLink } from 'lucide-react';
import { Logo } from '../ui/Logo';
import { siteConfig } from '../../data/site';
import { destinations } from '../../data/destinations';

const CURRENT_YEAR = new Date().getFullYear();

export const Footer: React.FC = () => {

  return (
    <footer className="bg-navy text-slate-300 border-t border-gold/20 pt-16 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-8 pb-12 border-b border-white/10">
          {/* Col 1: Brand & Bio */}
          <div className="lg:col-span-2 space-y-4">
            <Logo variant="light" showTagline />
            <p className="text-sm text-slate-400 font-light leading-relaxed max-w-sm mt-3">
              Wanderlux Travels crafts extraordinary, tailor-made journeys for discerning travelers. From pristine Maldivian lagoons and alpine Swiss chalets to the dramatic granite spires of northern Pakistan, we create memories beyond the ordinary.
            </p>

            <div className="pt-2 text-xs text-gold-light/90 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-gold shrink-0" />
              <span>Certified partner accommodations & licensed ground operators</span>
            </div>

            {/* Fact & Credit Docs */}
            <div className="pt-2 flex flex-wrap gap-3 text-xs">
              <a
                href="/DATA_SOURCES.md"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-gold flex items-center gap-1 transition-colors"
              >
                <span>Fact Verification Registry</span>
                <ExternalLink className="w-3 h-3" />
              </a>
              <span className="text-white/20">•</span>
              <a
                href="/images/CREDITS.md"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-gold flex items-center gap-1 transition-colors"
              >
                <span>Image Credits Registry</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div>
            <h4 className="font-serif text-white text-base font-semibold tracking-wide mb-4 flex items-center gap-2">
              <Compass className="w-4 h-4 text-gold" />
              <span>Explore</span>
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <Link to="/" className="hover:text-gold transition-colors">Home</Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-gold transition-colors">About Us & Philosophy</Link>
              </li>
              <li>
                <Link to="/destinations" className="hover:text-gold transition-colors">All 13 Destinations</Link>
              </li>
              <li>
                <Link to="/packages" className="hover:text-gold transition-colors">Tour Packages</Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-gold transition-colors">Travel Services</Link>
              </li>
              <li>
                <Link to="/gallery" className="hover:text-gold transition-colors">Inspiration Gallery</Link>
              </li>
              <li>
                <Link to="/blog" className="hover:text-gold transition-colors">Travel Guides & Blog</Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-gold transition-colors">Trip Consultation</Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Popular Destinations */}
          <div>
            <h4 className="font-serif text-white text-base font-semibold tracking-wide mb-4">
              Featured Destinations
            </h4>
            <ul className="space-y-2 text-xs">
              {destinations.slice(0, 7).map((d) => (
                <li key={d.slug}>
                  <Link to={`/destinations/${d.slug}`} className="hover:text-gold transition-colors">
                    {d.name}, {d.country}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Services & Contact Consultation */}
          <div>
            <h4 className="font-serif text-white text-base font-semibold tracking-wide mb-4">
              Consultation Desk
            </h4>
            <div className="space-y-3 text-xs text-slate-300">
              <div className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                <span>{siteConfig.businessHours}</span>
              </div>

              {siteConfig.isContactConfigured ? (
                <>
                  <div className="flex items-start gap-2.5">
                    <Phone className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                    <a href={`tel:${siteConfig.phone}`} className="hover:text-gold">{siteConfig.phone}</a>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <Mail className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                    <a href={`mailto:${siteConfig.email}`} className="hover:text-gold">{siteConfig.email}</a>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <MapPin className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                    <span>{siteConfig.address}</span>
                  </div>
                </>
              ) : (
                <div className="p-3 bg-white/5 rounded-xl border border-white/10 text-slate-400 text-[11px] leading-relaxed">
                  <span className="text-gold-light font-medium block mb-1">Direct Contact Placement</span>
                  Official headquarters phone numbers and office addresses can be configured directly in <code className="text-white bg-black/40 px-1 py-0.5 rounded">src/data/site.ts</code>. Online inquiries remain operational.
                </div>
              )}

              <div className="pt-2">
                <Link
                  to="/contact"
                  className="inline-flex py-2 px-4 rounded-xl bg-gold text-navy font-semibold text-xs uppercase tracking-wider hover:bg-gold-light transition-colors"
                >
                  Send Travel Inquiry
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Methods & Legal Disclaimer */}
        <div className="pt-8 pb-4 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            <span className="font-medium text-slate-300">Payment Modes Accepted: </span>
            <span>Direct Bank Wire Transfer (IBAN/SWIFT), PayPak, Visa, MasterCard, and certified Pay Order.</span>
          </div>
          <div className="flex items-center space-x-6">
            <Link to="/privacy-policy" className="hover:text-gold transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-gold transition-colors">Terms & Conditions</Link>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-4 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500">
          <p>© {CURRENT_YEAR} Wanderlux Travels. All rights reserved. Journeys Crafted Beyond the Ordinary.</p>
          <p>Prices quoted in Pakistani Rupees (PKR) as indicative luxury planning estimates.</p>
        </div>
      </div>
    </footer>
  );
};
