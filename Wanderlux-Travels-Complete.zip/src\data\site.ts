import type { SiteConfig } from '../types';

export const siteConfig: SiteConfig = {
  brandName: 'Wanderlux Travels',
  tagline: 'Journeys Crafted Beyond the Ordinary',
  canonicalUrl: 'https://wanderluxtravels.com',
  // Contact details are kept as editable placeholders per prompt requirements
  // Change isContactConfigured to true once actual phone/email are provided
  isContactConfigured: false,
  email: 'REPLACE_WITH_REAL_EMAIL',
  phone: 'REPLACE_WITH_REAL_PHONE',
  whatsapp: 'REPLACE_WITH_REAL_WHATSAPP',
  address: 'REPLACE_WITH_VERIFIED_ADDRESS',
  businessHours: 'Monday – Saturday: 09:30 AM – 06:30 PM (PKT)',
  defaultDepartureCity: 'Islamabad / Lahore / Karachi',
  defaultNationality: 'Pakistani Passport Holder (Editable in site.ts)',
  currency: {
    code: 'PKR',
    symbol: '₨',
  },
  socials: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    linkedin: 'https://linkedin.com',
  },
};
